MEGPRO FITNESS — Engineered for Progress
============================

Theme: light orange + white
Platforms: mobile-friendly website; can be installed on Android when hosted over HTTPS.

Files:
- index.html: the app
- manifest.json: installable web-app metadata
- sw.js: basic offline cache for supported browsers

TRY IT
1. Unzip this package.
2. Open index.html in a browser. Install/offline features require hosting over HTTPS.
3. Your entries are stored locally in that browser on that device.

INSTALL ON ANDROID
1. Upload these files to an HTTPS static host.
2. Open the hosted site in Chrome on Android.
3. Open Chrome menu (⋮) and choose "Add to Home screen" or "Install app".

This package is a working starter prototype, not a published APK. A standalone APK requires an Android wrapper/build process.

PERSONALIZATION
Workout exercises and habits can be edited inside the app. Share your real workout and diet plans to customize Megpro to match them.
